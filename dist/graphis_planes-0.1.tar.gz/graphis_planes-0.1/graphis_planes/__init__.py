print("Inicializando graphis_planes")

# Puedes definir variables globales o realizar alguna configuración
__version__ = "0.1"